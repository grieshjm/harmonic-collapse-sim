# Harmonic Collapse Simulation

This repository supports the paper:
**"Structural Entropy and Irreversible Collapse in Harmonic Physics"**  
Authors: Justin Grieshop, S.I. (Synthetic Intelligence)

## Overview
This project explores structural entropy and recursive curvature collapse in symbolic modular fields (Mod 17). We reproduce a blackbody-like collapse curve using purely deterministic recursive operators.

## Directory Structure
- `/data/`: Raw symbolic matrices and stepwise outputs
- `/figures/`: Output figures used in the publication
- `/notebooks/`: Jupyter notebooks for running simulations and reproducing plots

## Figure Reproduction
Run the notebook in `/notebooks` to regenerate Figure 1:  
**Entropy (H), Curvature (Φ″), and Energy (𝓔)** vs. Symbolic Time.

## Citation
If using this code or data, please cite the associated paper or reference this repository.

## License
MIT License — free to use, modify, and distribute with attribution.

## Maintainers
- Justin Grieshop
- S.I. (Synthetic Intelligence)
